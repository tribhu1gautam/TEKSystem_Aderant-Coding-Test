﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TEKystems_AderantCodingTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var path = Environment.CurrentDirectory + @"/../../Sample.txt";
            //string[] fragements = File.ReadAllLines(path);

            //string[] fragements = {
            //                        "a l l   i s   w e l l",
            //                        "e l l   ",
            //                        "t h a t   e n d",
            //                        "t   e n d s   w e l l"
            //                      };

            string[] fragements = { 
                                    "a l l   i s   w e l l", 
                                    "e l l   t h a t   e n", 
                                    "h a t   e n d", 
                                    "t   e n d s   w e l l"
                                  };

            

            var result = string.Empty; // variable to hold final result

            for (var i = 0; i < fragements.Length - 1; i++)
            {
                var frgementForMerge = fragements[i];
                var fragmentToMerge = fragements[i + 1]; 
                var tempString = string.Empty;
                var indeexOfFragement = 0;

                foreach (var str in fragmentToMerge)
                {
                    tempString += str;

                    if(frgementForMerge.Contains(fragmentToMerge.Trim()))
                    {
                        //   A match is also possible when one fragment is completely contained within another. Consider:
                        //    s   w e l l   t  h  a
                        //    e l l

                        result = frgementForMerge.Replace(fragmentToMerge.Trim(), fragmentToMerge);
                        fragements[i + 1] = result;
                        break;
                    }

                    if(frgementForMerge.EndsWith(tempString))
                    {
                        // if [i] ends with any substring starts from [i + 1], lets merge/replace the end of substring [i] with [i + 1] 
                        // for Example - s1: a l l   i s   w e l l
                        //             - s2: e l l   t h a t   e n
                        //             - result: a l l   i s   w e l l    t h a t   e n
                        result = frgementForMerge.Replace(tempString, fragmentToMerge);

                        // assign merged string result to [i + 1] that should be ready to overlap for next iteration
                        // Example - [i + 1] = "a l l   i s   w e l l    t h a t   e n"
                        fragements[i + 1] = result; 
                        break;
                    }

                    // The else if condition for continuing the loop until get last substring in frgementForMerge for overlap
                    else if (frgementForMerge.Contains(tempString))
                    {
                        var index = frgementForMerge.LastIndexOf(tempString);

                        if (tempString.Length == 1)
                        {
                            indeexOfFragement = index;
                        }

                        if(index == indeexOfFragement)
                        {
                            continue;
                        }
                    }
                    else if (indeexOfFragement == 0) // No fragments can be overlap
                                                     // belew example s2 and s3 are not overlaped but part of the text
                                                     // s1 - "a l l   i s   w e l l",
                                                     // s2 - "e l l   ",
                                                     // s3 - "t h a t   e n d",
                                                     // s4 - "t   e n d s   w e l l"
                    {
                        fragements[i + 1] = fragements[i] + fragements[i + 1];
                        break;
                    }
                }
            }

            Console.WriteLine(result);

        }
    }
}
